#!/bin/bash

# script wrapper to start the Tomcat instance as swifiic for SOA

sudo su -p -s /bin/sh swifiic HubSrvr/bin/startup.sh
